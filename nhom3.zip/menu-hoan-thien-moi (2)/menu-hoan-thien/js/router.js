/* =====================================================================
   FILE: router.js - ĐIỀU HƯỚNG
   Web chỉ có 1 file index.html nhưng nhiều "trang".
   Địa chỉ  index.html#/menu  -> hiện trang "menu".
   Phần sau dấu #  gọi là "hash". Khi hash đổi, ta vẽ lại trang tương ứng.
   ===================================================================== */

import { $ } from "./helpers.js";
import { me, isAdmin } from "./data.js";
import { renderHeader } from "./layout.js";

import { pageHome } from "./pages/home.js";
import { pageMenu, drawMenu, showDetail, setMenuCat } from "./pages/menu.js";
import { pageNews, pageNewsDetail } from "./pages/news.js";
import { pageContact } from "./pages/contact.js";
import { pageLogin, pageRegister, pageForgot, pageAccount } from "./pages/auth.js";
import { pageCart } from "./pages/cart.js";
import { pageMyOrders } from "./pages/orders.js";
import { pageAdmin } from "./admin/admin.js";

// Bảng tra: tên trang -> hàm vẽ trang đó
const pages = {
  home: pageHome,
  menu: pageMenu,
  news: pageNews,
  newsdetail: pageNewsDetail, // trang chi tiết 1 bài: #/newsdetail?id=3
  contact: pageContact,
  login: pageLogin,
  register: pageRegister,
  forgot: pageForgot,
  cart: pageCart,
  orders: pageMyOrders,
  account: pageAccount
};

// Hàm chính: đọc hash -> chọn trang -> vẽ ra màn hình
export async function route(keepScroll) {
  // Bước 1: đọc hash.  Ví dụ "#/menu?mon=3"  ->  name = "menu", query có mon = 3
  const hash = location.hash.replace("#/", "");
  const parts = hash.split("?");
  const name = parts[0] || "home";
  const query = new URLSearchParams(parts[1] || "");
  const y = keepScroll === true ? window.scrollY : 0; // true = giữ vị trí cuộn

  // Bước 2: trang quản trị (admin) là trang riêng: ẩn header, footer của khách
  const isAdminPage = name.startsWith("admin");
  document.body.classList.toggle("is-admin", isAdminPage);
  if (isAdminPage) {
    if (!me) {
      location.hash = "#/login"; // chưa đăng nhập -> sang trang đăng nhập
      return;
    }
    $("app").innerHTML = await pageAdmin(name); // pageAdmin tự kiểm tra có phải admin không
    window.scrollTo(0, y);
    return;
  }

  // Bước 3: kiểm tra quyền vào các trang của khách
  const needLogin = name === "cart" || name === "orders" || name === "account";
  const guestOnly = name === "login" || name === "register" || name === "forgot";
  if (needLogin && !me) {
    location.hash = "#/login"; // chưa đăng nhập -> chuyển sang trang đăng nhập
    return;
  }
  if (needLogin && isAdmin()) {
    location.hash = "#/admin"; // admin không có giỏ hàng / đơn hàng riêng
    return;
  }
  if (guestOnly && me) {
    location.hash = "#/home"; // đã đăng nhập rồi thì khỏi vào trang đăng nhập
    return;
  }

  // Bước 4: tìm hàm vẽ trang rồi đưa HTML vào khung #app
  const drawPage = pages[name] || pageHome; // không có tên đó thì về trang chủ
  $("app").innerHTML = await drawPage(query);

  // Bước 5: việc riêng của trang thực đơn
  if (name === "menu") {
    const cat = Number(query.get("cat"));
    if (cat) setMenuCat(cat); // đi từ sidebar trang chủ: mở sẵn danh mục
    await drawMenu();
    const id = Number(query.get("mon"));
    if (id) await showDetail(id); // đi từ trang chủ sang: mở sẵn chi tiết món
  }

  await renderHeader(name === "newsdetail" ? "news" : name); // trang chi tiết tin tô đậm mục "Tin tức"
  window.scrollTo(0, y);
}

// Mỗi khi hash đổi (bấm link, nút Back...) thì vẽ lại
window.addEventListener("hashchange", function () {
  route();
});

// Các trang gọi refresh() (trong helpers.js) khi cần vẽ lại mà giữ nguyên vị trí cuộn
window.addEventListener("refresh", function () {
  route(true);
});
