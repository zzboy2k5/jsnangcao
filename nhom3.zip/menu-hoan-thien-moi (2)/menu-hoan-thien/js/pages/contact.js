/* =====================================================================
   FILE: pages/contact.js - TRANG LIÊN HỆ
   HTML: html/pages/contact.html
   ===================================================================== */

import { loadHTML, fill, safe } from "../helpers.js";
import { db } from "../data.js";

// Cửa hàng đang mở hay đóng? (T2-T6: 7-22h, T7-CN: 8-23h)
function openStatus() {
  const now = new Date();
  const weekend = now.getDay() === 0 || now.getDay() === 6;
  const open = weekend ? 8 : 7;
  const close = weekend ? 23 : 22;
  const h = now.getHours() + now.getMinutes() / 60;
  if (h >= open && h < close) {
    return `<span class="open-state on">● Đang mở cửa · đóng lúc ${close}:00</span>`;
  }
  return `<span class="open-state off">● Đã đóng cửa · mở lúc ${open}:00</span>`;
}

export async function pageContact() {
  const s = db.shop;
  const page = await loadHTML("html/pages/contact.html");
  const weekend = [0, 6].indexOf(new Date().getDay()) !== -1;
  return fill(page, {
    address: safe(s.address),
    mapQuery: encodeURIComponent(s.address + ", Việt Nam"),
    hotline: safe(s.hotline),
    zalo: safe(s.zalo),
    email: safe(s.email),
    openStatus: openStatus(),
    todayWeek: weekend ? "" : "today",
    todayEnd: weekend ? "today" : "",
    freeShip: s.freeShipFrom.toLocaleString("vi-VN"),
    shipFee: s.shipFee.toLocaleString("vi-VN")
  });
}
