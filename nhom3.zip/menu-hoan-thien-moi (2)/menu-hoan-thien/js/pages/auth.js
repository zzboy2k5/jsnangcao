/* =====================================================================
   FILE: pages/auth.js - TÀI KHOẢN
   Đăng nhập, đăng ký, quên mật khẩu, trang tài khoản, đăng xuất.
   Mỗi trang gồm 2 phần:
     - pageXxx()         : trả về HTML của trang (HTML nằm trong html/pages/)
     - forms.xxxForm     : hàm chạy khi bấm nút gửi của form đó

   Quy tắc tài khoản:
     - Admin: viết cứng trong data.js (ADMIN), không đăng ký được.
     - Ai đăng ký mới đều là KHÁCH HÀNG (role = "user").
   ===================================================================== */

import { $, loadHTML, fill, safe, nextId, norm, cleanPhone, phoneOK, showError, toast, goto } from "../helpers.js";
import { db, me, ADMIN, saveDB, isAdmin, login, logout, phoneExists, newUserId } from "../data.js";
import { forms, actions, inputs } from "../events.js";
import { renderHeader } from "../layout.js";
import { myOrdersHTML } from "./orders.js";

/* ---------- Đăng nhập ---------- */
export async function pageLogin() {
  return await loadHTML("html/pages/login.html");
}

forms.loginForm = function (f) {
  const phone = cleanPhone(f.phone.value);
  const password = f.password.value;

  // Bước 1: có phải admin không? (so với tài khoản viết cứng ADMIN)
  let user = null;
  if (phone === ADMIN.phone && password === ADMIN.password) {
    user = ADMIN;
  }

  // Bước 2: không phải admin thì tìm trong danh sách khách hàng
  if (user === null) {
    for (let i = 0; i < db.users.length; i++) {
      const u = db.users[i];
      if (u.phone === phone && u.password === password) user = u;
    }
  }

  if (user === null) return showError(f, "Sai số điện thoại hoặc mật khẩu");
  if (user.locked) return showError(f, "Tài khoản đã bị khóa. Vui lòng liên hệ cửa hàng.");

  login(user);
  toast("Xin chào " + user.name + " 👋");
  goto(isAdmin() ? "#/admin" : "#/home"); // admin vào thẳng trang quản trị
};

/* ---------- Đăng ký ---------- */
export async function pageRegister() {
  return await loadHTML("html/pages/register.html");
}

forms.registerForm = function (f) {
  const name = f.name.value.trim();
  const phone = cleanPhone(f.phone.value);

  // Kiểm tra từng điều kiện. Sai điều kiện nào thì báo lỗi và DỪNG (return)
  if (name.length < 2) return showError(f, "Vui lòng nhập họ tên");
  if (!phoneOK(phone)) return showError(f, "Số điện thoại chưa đúng (10 số, bắt đầu 03, 05, 07, 08, 09)");
  if (phoneExists(phone, 0)) return showError(f, "Số điện thoại này đã được đăng ký");
  if (f.password.value.length < 6) return showError(f, "Mật khẩu phải có ít nhất 6 ký tự");
  if (f.password.value !== f.password2.value) return showError(f, "Hai mật khẩu chưa giống nhau");

  // Mọi thứ đúng -> tạo khách hàng mới. role luôn là "user" (khách hàng)
  const user = {
    id: newUserId(),
    address: "",
    name: name,
    phone: phone,
    password: f.password.value,
    role: "user",
    locked: false,
    created: new Date().toLocaleDateString("vi-VN")
  };
  db.users.push(user);
  saveDB();

  login(user);
  toast("Đăng ký thành công 🎉");
  goto("#/home");
};

/* ---------- Quên mật khẩu (xác minh bằng số điện thoại + họ tên) ---------- */
export async function pageForgot() {
  return await loadHTML("html/pages/forgot.html");
}

forms.forgotForm = function (f) {
  const phone = cleanPhone(f.phone.value);

  let user = null;
  for (let i = 0; i < db.users.length; i++) {
    const u = db.users[i];
    if (u.phone === phone && norm(u.name) === norm(f.name.value)) user = u;
  }

  if (user === null) return showError(f, "Số điện thoại và họ tên không khớp tài khoản nào");
  if (f.password.value.length < 6) return showError(f, "Mật khẩu mới phải có ít nhất 6 ký tự");
  if (f.password.value !== f.password2.value) return showError(f, "Hai mật khẩu chưa giống nhau");

  user.password = f.password.value;
  saveDB();
  toast("Đã đổi mật khẩu, hãy đăng nhập lại ✅");
  goto("#/login");
};

/* ---------- Ẩn / hiện mật khẩu + thanh đo độ mạnh mật khẩu ---------- */
actions.togglePw = function (el) {
  const input = el.closest(".field").querySelector("input");
  const show = input.type === "password";
  input.type = show ? "text" : "password";
  el.textContent = show ? "Ẩn" : "Hiện";
};

inputs.regPass = function (el) {
  const v = el.value;
  let score = 0;
  if (v.length >= 6) score++;
  if (v.length >= 9) score++;
  if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
  if (/\d/.test(v) && /[^A-Za-z0-9]/.test(v)) score++;
  if (v === "") score = -1;
  const labels = ["Yếu", "Trung bình", "Khá", "Mạnh"];
  const bar = $("pwBar");
  bar.style.width = score < 0 ? "0" : ((score + 1) * 25) + "%";
  bar.className = "s" + Math.max(score, 0);
  $("pwText").textContent = score < 0 ? "Ít nhất 6 ký tự" : "Độ mạnh: " + labels[Math.min(score, 3)];
};

/* ---------- Đăng xuất ---------- */
actions.logout = function () {
  logout();
  toast("Đã đăng xuất");
  goto("#/home");
};

/* ---------- Trang tài khoản (sửa thông tin + đổi mật khẩu + xem đơn) ---------- */
export async function pageAccount() {
  const page = await loadHTML("html/pages/account.html");
  return fill(page, {
    name: safe(me.name),
    phone: safe(me.phone),
    address: safe(me.address || ""),
    orders: await myOrdersHTML()
  });
}

forms.accountForm = function (f) {
  const name = f.name.value.trim();
  const phone = cleanPhone(f.phone.value);

  if (name.length < 2) return showError(f, "Vui lòng nhập họ tên");
  if (!phoneOK(phone)) return showError(f, "Số điện thoại chưa đúng");
  if (phoneExists(phone, me.id)) return showError(f, "Số điện thoại này đã có người khác dùng");

  me.name = name;
  me.phone = phone;
  me.address = f.address.value.trim();
  saveDB();
  renderHeader("account");
  toast("Đã lưu thông tin ✅");
};

forms.passwordForm = function (f) {
  if (f.oldPass.value !== me.password) return showError(f, "Mật khẩu hiện tại chưa đúng");
  if (f.newPass.value.length < 6) return showError(f, "Mật khẩu mới phải có ít nhất 6 ký tự");
  if (f.newPass.value !== f.newPass2.value) return showError(f, "Hai mật khẩu mới chưa giống nhau");

  me.password = f.newPass.value;
  saveDB();
  f.reset();
  toast("Đã đổi mật khẩu ✅");
};
