/* =====================================================================
   FILE: pages/menu.js - TRANG THỰC ĐƠN (lọc + tìm + phân trang + chi tiết món)
   HTML: html/pages/menu.html, html/pages/product-detail.html,
         html/components/menu-chip.html, empty.html
   ===================================================================== */

import { $, loadHTML, fill, safe, norm, formatPrice, findById, pagerHTML } from "../helpers.js";
import { db, isToppingCategory } from "../data.js";
import { actions, inputs, changes } from "../events.js";
import { productCard } from "../components.js";
import { stockOf, stockState, stockBadge, matchStock, sortLowFirst } from "../stock.js";

const PAGE_SIZE = 6; // mỗi trang hiện 6 món

// Trạng thái bộ lọc hiện tại. cat = 0 nghĩa là "Tất cả"
let menuState = { cat: 0, page: 1, keyword: "", stock: "" };

// Lấy danh sách món THỎA bộ lọc (đúng danh mục, đúng từ khóa, không bị ẩn)
function visibleProducts() {
  const result = [];
  for (let i = 0; i < db.products.length; i++) {
    const p = db.products[i];
    const dungDanhMuc = menuState.cat === 0 || p.categoryId === menuState.cat;
    const dungTuKhoa = norm(p.name).includes(norm(menuState.keyword));
    if (!p.hidden && !isToppingCategory(p.categoryId) && dungDanhMuc && dungTuKhoa && matchStock(p, menuState.stock)) {
      result.push(p);
    }
  }
  return sortLowFirst(result, true); // món sắp hết hàng (dưới 10) nhảy lên đầu
}

// Trả về khung trang thực đơn (còn rỗng). Phần nút + danh sách món do drawMenu() vẽ sau.
export async function pageMenu() {
  menuState = { cat: 0, page: 1, keyword: "", stock: "" }; // mỗi lần vào trang là reset bộ lọc
  return await loadHTML("html/pages/menu.html");
}

// Vẽ lại phần nút danh mục + lưới món (mỗi lần lọc / đổi trang thì gọi lại hàm này)
export async function drawMenu() {
  const list = visibleProducts();

  // Cắt đúng 6 món của trang hiện tại
  const start = (menuState.page - 1) * PAGE_SIZE;
  const part = list.slice(start, start + PAGE_SIZE);

  // Các nút danh mục (thêm nút "Tất cả" vào đầu)
  const chipTemplate = await loadHTML("html/components/menu-chip.html");
  let chips = fill(chipTemplate, { on: menuState.cat === 0 ? "on" : "", id: 0, name: "Tất cả" });
  for (let i = 0; i < db.categories.length; i++) {
    const c = db.categories[i];
    if (isToppingCategory(c.id)) continue; // bỏ nút Topping
    chips += fill(chipTemplate, { on: c.id === menuState.cat ? "on" : "", id: c.id, name: safe(c.name) });
  }
  $("menuChips").innerHTML = chips;

  // Lưới món
  if (part.length === 0) {
    const empty = await loadHTML("html/components/empty.html");
    $("menuList").innerHTML = fill(empty, { text: "Không tìm thấy món nào 😢" });
    return;
  }
  let cards = "";
  for (let i = 0; i < part.length; i++) {
    cards += await productCard(part[i], "detail");
  }
  $("menuList").innerHTML = `<div class="grid">${cards}</div>` + pagerHTML(list.length, menuState.page, PAGE_SIZE, "menuPage");
}

// Mở thực đơn sẵn một danh mục (dùng cho link ở sidebar trang chủ)
export function setMenuCat(id) {
  menuState.cat = id;
}

// Đổi ô lọc "Còn hàng / Hết hàng"
changes.menuStock = function (el) {
  menuState.stock = el.value;
  menuState.page = 1;
  drawMenu();
};

// Bấm nút danh mục
actions.menuCat = function (el) {
  menuState.cat = Number(el.dataset.id);
  menuState.page = 1;
  drawMenu();
};

// Bấm số trang
actions.menuPage = function (el) {
  menuState.page = Number(el.dataset.page);
  drawMenu();
};

// Gõ chữ vào ô tìm kiếm thì lọc lại danh sách món
inputs.search = function (el) {
  menuState.keyword = el.value;
  menuState.page = 1;
  drawMenu();
};

// Bấm vào 1 món trong thực đơn -> hiện chi tiết
actions.detail = function (el) {
  showDetail(Number(el.dataset.id));
};

/* ---------- Khung chi tiết món (hiện phía trên danh sách) ---------- */
export async function showDetail(id) {
  const p = findById(db.products, id);
  if (p === null) return;

  // Bảng size + giá
  let sizeRows = "";
  for (let i = 0; i < p.sizes.length; i++) {
    const s = p.sizes[i];
    sizeRows += `<tr><td>${safe(s.size)}</td><td>${safe(s.ml)}</td><td class="price">${formatPrice(s.price)}</td></tr>`;
  }

  // Các lựa chọn nóng / lạnh
  let temps = "";
  for (let i = 0; i < p.temps.length; i++) {
    temps += `<div class="temp">${p.temps[i]}</div>`;
  }

  // Ô chọn size
  let sizeOptions = "";
  for (let i = 0; i < p.sizes.length; i++) {
    const s = p.sizes[i];
    sizeOptions += `<option value="${safe(s.size)}">${safe(s.size)} - ${formatPrice(s.price)}</option>`;
  }

  const stock = stockOf(p);
  const out = stock === 0;
  const template = await loadHTML("html/pages/product-detail.html");
  $("detailBox").innerHTML = fill(template, {
    id: p.id,
    img: p.img,
    name: safe(p.name),
    desc: safe(p.desc),
    temps: temps,
    sizeRows: sizeRows,
    sizeOptions: sizeOptions,
    stockBadge: stockBadge(p),
    stockNote: out ? "Sản phẩm tạm hết hàng, vui lòng quay lại sau." : (stockState(p) === "low" ? "Chỉ còn " + stock + " sản phẩm, đặt nhanh kẻo hết!" : ""),
    maxQty: Math.max(1, Math.min(20, stock)),
    orderAttr: out ? "disabled" : "",
    btnText: out ? "Hết hàng" : "🛒 Đặt sản phẩm"
  });
  $("detailBox").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

actions.closeDetail = function () {
  $("detailBox").innerHTML = "";
};
