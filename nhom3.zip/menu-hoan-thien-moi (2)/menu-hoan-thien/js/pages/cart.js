/* =====================================================================
   FILE: pages/cart.js - GIỎ HÀNG VÀ ĐẶT HÀNG
   HTML: html/pages/cart.html, cart-row.html, cart-empty.html
   Dữ liệu giỏ hàng (đọc / ghi / tính tiền) nằm ở js/cart-data.js
   ===================================================================== */

import { $, findById, loadHTML, fill, safe, formatPrice, nextId, cleanPhone, phoneOK, showError, toast, goto, refresh } from "../helpers.js";
import { db, me, isAdmin, saveDB } from "../data.js";
import { actions, forms } from "../events.js";
import { renderHeader } from "../layout.js";
import { getCart, setCart, cartLines, subtotalOf, shipFee } from "../cart-data.js";
import { stockOf, qtyInCart, deductStock } from "../stock.js";

/* ---------- Thêm vào giỏ (nút "Đặt sản phẩm" trong khung chi tiết) ---------- */
actions.addCart = function (el) {
  if (!me) {
    toast("Hãy đăng nhập để đặt sản phẩm");
    location.hash = "#/login";
    return;
  }
  if (isAdmin()) {
    toast("Admin không đặt hàng. Hãy dùng tài khoản khách hàng nhé");
    return;
  }

  const productId = Number(el.dataset.id);
  const size = $("sizeSel").value;
  let qty = Math.floor(Number($("qtyIn").value));
  if (!qty || qty < 1) qty = 1;
  if (qty > 20) qty = 20;

  const cart = getCart();

  // Kiểm tra tồn kho (các size của cùng 1 món dùng chung 1 kho)
  const product = findById(db.products, productId);
  const stock = product ? stockOf(product) : 0;
  if (stock === 0) return toast("Sản phẩm này đã hết hàng 😢");
  const canAdd = stock - qtyInCart(cart, productId);
  if (canAdd <= 0) return toast("Bạn đã có " + stock + " ly trong giỏ, đã hết số lượng tồn kho");
  if (qty > canAdd) {
    qty = canAdd;
    toast("Chỉ còn " + stock + " sản phẩm, đã thêm tối đa " + canAdd + " ly vào giỏ");
  } else {
    toast("Đã thêm vào giỏ hàng 🛒");
  }

  // Món + size này đã có trong giỏ chưa? Có rồi thì cộng thêm số lượng
  let found = false;
  for (let i = 0; i < cart.length; i++) {
    if (cart[i].productId === productId && cart[i].size === size) {
      cart[i].qty += qty;
      found = true;
    }
  }
  if (!found) {
    cart.push({ productId: productId, size: size, qty: qty });
  }

  setCart(cart);
  renderHeader("menu"); // cập nhật số lượng trên header
};

/* ---------- Trang giỏ hàng ---------- */
export async function pageCart() {
  const lines = cartLines();

  if (lines.length === 0) {
    return await loadHTML("html/pages/cart-empty.html");
  }

  const rowTemplate = await loadHTML("html/pages/cart-row.html");
  let rows = "";
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    rows += fill(rowTemplate, {
      name: safe(l.name),
      size: l.size,
      price: formatPrice(l.price),
      index: l.index,
      qty: l.qty,
      minusAttr: l.qty <= 1 ? "disabled" : "",
      plusAttr: qtyInCart(getCart(), l.productId) >= l.stock ? "disabled" : "",
      lineTotal: formatPrice(l.price * l.qty)
    });
  }

  const subtotal = subtotalOf(lines);
  const ship = shipFee(subtotal);

  // Khách đã có địa chỉ lưu từ lần đặt trước thì không phải nhập lại
  let addressBlock;
  if (me.address) {
    addressBlock = fill(await loadHTML("html/pages/cart-address-saved.html"), { address: safe(me.address) });
  } else {
    addressBlock = await loadHTML("html/pages/cart-address-new.html");
  }

  const page = await loadHTML("html/pages/cart.html");
  return fill(page, {
    addressBlock: addressBlock,
    rows: rows,
    subtotal: formatPrice(subtotal),
    ship: ship === 0 ? "Miễn phí" : formatPrice(ship),
    total: formatPrice(subtotal + ship),
    name: safe(me.name),
    phone: safe(me.phone)
  });
}

// Nút − + Xóa trong giỏ. data-d là số cộng thêm: -1, +1 hoặc -99 (để xóa hẳn)
// Số lượng tối thiểu là 1: bấm − khi còn 1 thì KHÔNG làm mất món, muốn bỏ món phải bấm "Xóa".
actions.cartQty = function (el) {
  const cart = getCart();
  const item = cart[Number(el.dataset.i)];
  const d = Number(el.dataset.d);
  if (!item) return;

  if (d === -99) {
    cart.splice(Number(el.dataset.i), 1); // xóa hẳn dòng này
  } else if (d < 0) {
    if (item.qty <= 1) return toast("Số lượng tối thiểu là 1. Bấm \"Xóa\" nếu muốn bỏ món này");
    item.qty -= 1;
  } else {
    const product = findById(db.products, item.productId);
    const stock = product ? stockOf(product) : 0;
    if (qtyInCart(cart, item.productId) >= stock) return toast("Chỉ còn " + stock + " sản phẩm trong kho");
    item.qty += 1;
  }
  setCart(cart);
  renderHeader("cart"); // cập nhật số trên header
  refresh(); // vẽ lại trang, giữ nguyên vị trí cuộn
};

// Bấm "Đổi địa chỉ": thay khung địa chỉ đã lưu bằng ô nhập
actions.editAddr = async function () {
  $("addrBox").innerHTML = await loadHTML("html/pages/cart-address-new.html");
  const input = document.querySelector('#checkoutForm [name="address"]');
  input.value = me.address || "";
  input.focus();
};

/* ---------- Đặt hàng ---------- */
forms.checkoutForm = function (f) {
  const lines = cartLines();
  const name = f.name.value.trim();
  const phone = cleanPhone(f.phone.value);
  const address = f.address.value.trim();

  if (lines.length === 0) return showError(f, "Giỏ hàng đang trống");
  if (name === "" || address.length < 5) return showError(f, "Vui lòng nhập họ tên và địa chỉ giao hàng");
  if (!phoneOK(phone)) return showError(f, "Số điện thoại chưa đúng (10 số)");

  // Kiểm tra lại tồn kho lần cuối (có thể đã đổi từ lúc bỏ vào giỏ)
  const cartNow = getCart();
  for (let i = 0; i < lines.length; i++) {
    const have = lines[i].stock;
    if (qtyInCart(cartNow, lines[i].productId) > have) {
      return showError(f, lines[i].name + (have === 0 ? " đã hết hàng" : " chỉ còn " + have + " sản phẩm") + ". Vui lòng chỉnh lại giỏ hàng");
    }
  }

  const subtotal = subtotalOf(lines);
  const ship = shipFee(subtotal);
  const id = nextId(db.orders);

  // Chép các dòng trong giỏ thành danh sách món của đơn
  const items = [];
  for (let i = 0; i < lines.length; i++) {
    items.push({ productId: lines[i].productId, name: lines[i].name, size: lines[i].size, price: lines[i].price, qty: lines[i].qty });
  }

  // unshift = thêm vào ĐẦU danh sách (đơn mới hiện trên cùng)
  db.orders.unshift({
    id: id,
    code: "DH" + String(id).padStart(4, "0"), // ví dụ DH0007
    userId: me.id,
    name: name,
    phone: phone,
    address: address,
    note: f.note.value.trim(),
    items: items,
    ship: ship,
    total: subtotal + ship,
    status: "Chờ xác nhận",
    time: new Date().toLocaleString("vi-VN")
  });
  deductStock(db.orders[0]); // trừ kho

  // Lưu địa chỉ cho lần đặt sau (lưu trong dữ liệu khách hàng, dạng JSON)
  me.address = address;
  saveDB();

  setCart([]); // đặt xong thì làm trống giỏ
  toast("Đặt hàng thành công 🎉");
  goto("#/orders");
};
