/* =====================================================================
   FILE: pages/orders.js - ĐƠN HÀNG CỦA TÔI (khách xem + hủy đơn)
   HTML: html/pages/orders.html, order-box.html
   ===================================================================== */

import { loadHTML, fill, safe, formatPrice, statusTag, toast, refresh } from "../helpers.js";
import { db, me, saveDB } from "../data.js";
import { actions } from "../events.js";
import { restoreStock } from "../stock.js";

// HTML danh sách đơn của người đang đăng nhập (trang tài khoản cũng dùng hàm này)
export async function myOrdersHTML() {
  const boxTemplate = await loadHTML("html/pages/order-box.html");
  let html = "";

  for (let i = 0; i < db.orders.length; i++) {
    const o = db.orders[i];
    if (!me || me.role === "admin" || o.userId !== me.id) continue; // chỉ lấy ĐÚNG đơn của người đang đăng nhập

    let itemsText = "";
    for (let j = 0; j < o.items.length; j++) {
      const it = o.items[j];
      itemsText += `• ${safe(it.name)} (${it.size}) x${it.qty} = ${formatPrice(it.price * it.qty)}<br>`;
    }

    // Chỉ đơn "Chờ xác nhận" mới có nút Hủy
    let cancelButton = "";
    if (o.status === "Chờ xác nhận") {
      cancelButton = `<button class="small-btn danger" data-act="cancelMyOrder" data-id="${o.id}">Hủy đơn</button>`;
    }

    html += fill(boxTemplate, {
      code: o.code,
      time: o.time,
      status: statusTag(o.status),
      items: itemsText,
      ship: formatPrice(o.ship),
      total: formatPrice(o.total),
      cancelButton: cancelButton
    });
  }

  if (html === "") {
    const empty = await loadHTML("html/components/empty.html");
    return fill(empty, { text: "Bạn chưa có đơn hàng nào." });
  }
  return html;
}

export async function pageMyOrders() {
  const page = await loadHTML("html/pages/orders.html");
  return fill(page, { orders: await myOrdersHTML() });
}

actions.cancelMyOrder = function (el) {
  const id = Number(el.dataset.id);
  for (let i = 0; i < db.orders.length; i++) {
    const o = db.orders[i];
    if (o.id === id && o.userId === me.id && o.status === "Chờ xác nhận") {
      if (!confirm("Hủy đơn " + o.code + "?")) return;
      o.status = "Đã hủy";
      restoreStock(o); // trả hàng về kho
      saveDB();
      refresh();
      return;
    }
  }
  toast("Đơn này không hủy được nữa");
};
