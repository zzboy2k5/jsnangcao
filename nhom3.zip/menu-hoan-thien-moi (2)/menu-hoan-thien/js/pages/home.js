/* =====================================================================
   FILE: pages/home.js - TRANG CHỦ (có sidebar bên phải)
   HTML: html/pages/home.html, home-sidebar.html
   Chỗ {{cards}}, {{news}}, {{sidebar}} sẽ được JS điền vào.
   Danh mục "Topping" bị bỏ khỏi trang chủ (cả món nổi bật lẫn sidebar).
   ===================================================================== */

import { loadHTML, fill, safe } from "../helpers.js";
import { db, isToppingCategory } from "../data.js";
import { actions } from "../events.js";
import { productCard, newsCard } from "../components.js";
import { stockOf, stockState, LOW_STOCK } from "../stock.js";

const isHiddenOnHome = isToppingCategory;

async function sidebarHTML() {
  // Danh mục (bỏ Topping) + số món đang bán
  let cats = "";
  for (let i = 0; i < db.categories.length; i++) {
    const c = db.categories[i];
    if (isHiddenOnHome(c.id)) continue;
    let count = 0;
    for (let j = 0; j < db.products.length; j++) {
      if (db.products[j].categoryId === c.id && !db.products[j].hidden) count++;
    }
    cats += `<a href="#/menu?cat=${c.id}"><span>${safe(c.name)}</span><em>${count}</em></a>`;
  }

  // Món sắp hết hàng (dưới 10), ít nhất xếp trước
  const low = db.products
    .filter(function (p) {
      return !p.hidden && !isHiddenOnHome(p.categoryId) && stockState(p) === "low";
    })
    .sort(function (a, b) {
      return stockOf(a) - stockOf(b);
    })
    .slice(0, 5);
  let lowList = "";
  for (let i = 0; i < low.length; i++) {
    lowList += `<a class="low-item" href="#/menu?mon=${low[i].id}"><img src="${low[i].img}" alt="" /><span>${safe(low[i].name)}</span><em>còn ${stockOf(low[i])}</em></a>`;
  }
  if (lowList === "") lowList = `<p class="muted">Hiện tất cả món đều còn nhiều hàng 🎉</p>`;

  // 3 tin mới nhất
  const itemTemplate = await loadHTML("html/pages/news-side-item.html");
  let newsList = "";
  for (let i = 0; i < 3 && i < db.news.length; i++) {
    const n = db.news[i];
    newsList += fill(itemTemplate, { id: n.id, img: n.img, title: safe(n.title), date: n.date });
  }

  const template = await loadHTML("html/pages/home-sidebar.html");
  return fill(template, {
    cats: cats,
    lowList: lowList,
    lowLimit: LOW_STOCK,
    newsList: newsList,
    hotline: safe(db.shop.hotline),
    freeShip: db.shop.freeShipFrom.toLocaleString("vi-VN")
  });
}

export async function pageHome() {
  // Món nổi bật = món đầu tiên của mỗi danh mục (bỏ Topping)
  let cards = "";
  for (let i = 0; i < db.categories.length; i++) {
    const cat = db.categories[i];
    if (isHiddenOnHome(cat.id)) continue;

    for (let j = 0; j < db.products.length; j++) {
      const p = db.products[j];
      if (p.categoryId === cat.id && !p.hidden) {
        cards += await productCard(p, "goDetail");
        break; // lấy món đầu tiên rồi thôi
      }
    }
  }

  // 3 tin mới nhất
  let news = "";
  for (let i = 0; i < 3 && i < db.news.length; i++) {
    news += await newsCard(db.news[i]);
  }

  const page = await loadHTML("html/pages/home.html");
  return fill(page, { cards: cards, news: news, sidebar: await sidebarHTML() });
}

// Từ trang chủ bấm vào món -> sang trang thực đơn và mở chi tiết món đó
actions.goDetail = function (el) {
  location.hash = "#/menu?mon=" + el.dataset.id;
};
