/* =====================================================================
   FILE: pages/news.js - TRANG TIN TỨC + TRANG CHI TIẾT 1 BÀI
   HTML: html/pages/news.html (danh sách), news-detail.html (chi tiết), news-side-item.html
   Danh sách: #/news     Chi tiết: #/newsdetail?id=3
   ===================================================================== */

import { loadHTML, fill, safe, findById, goto, toast } from "../helpers.js";
import { db } from "../data.js";
import { actions } from "../events.js";
import { newsCard } from "../components.js";

export async function pageNews() {
  let news = "";
  for (let i = 0; i < db.news.length; i++) {
    news += await newsCard(db.news[i]);
  }

  const page = await loadHTML("html/pages/news.html");
  return fill(page, { news: news });
}

// query = phần sau dấu ? trong địa chỉ (router truyền vào)
export async function pageNewsDetail(query) {
  const id = Number(query.get("id"));
  const n = findById(db.news, id);
  if (n === null) {
    toast("Không tìm thấy bài viết");
    location.hash = "#/news";
    return "";
  }

  // Nội dung: mỗi dòng trống / xuống dòng là 1 đoạn văn
  const paragraphs = n.content.split(/\n+/).map(function (t) {
    return "<p>" + safe(t) + "</p>";
  }).join("");

  // Các bài khác (cột bên phải)
  const itemTemplate = await loadHTML("html/pages/news-side-item.html");
  let others = "";
  for (let i = 0; i < db.news.length; i++) {
    const o = db.news[i];
    if (o.id === n.id) continue;
    others += fill(itemTemplate, { id: o.id, img: o.img, title: safe(o.title), date: o.date });
  }

  // Bài trước / bài sau
  const idx = db.news.indexOf(n);
  const prev = db.news[idx - 1];
  const next = db.news[idx + 1];
  const prevLink = prev ? `<a href="#/newsdetail?id=${prev.id}">‹ ${safe(prev.title)}</a>` : "<span></span>";
  const nextLink = next ? `<a href="#/newsdetail?id=${next.id}">${safe(next.title)} ›</a>` : "<span></span>";

  const page = await loadHTML("html/pages/news-detail.html");
  return fill(page, {
    img: n.img,
    tag: safe(n.tag),
    date: n.date,
    title: safe(n.title),
    summary: safe(n.summary),
    content: paragraphs,
    others: others,
    prevLink: prevLink,
    nextLink: nextLink
  });
}

// Nút "Quay lại" ở trang chi tiết
actions.newsBack = function () {
  goto("#/news");
};
