/* =====================================================================
   FILE: stock.js - TỒN KHO
   Mỗi sản phẩm có p.stock = số lượng còn trong kho (dùng chung cho mọi size).
     stock = 0      -> HẾT HÀNG
     1 .. 9         -> SẮP HẾT (báo đỏ, được đẩy lên đầu danh sách)
     từ 10 trở lên  -> CÒN HÀNG
   Muốn đổi ngưỡng "sắp hết" thì sửa LOW_STOCK.
   ===================================================================== */

import { db } from "./data.js";

export const LOW_STOCK = 10;

export function stockOf(p) {
  const n = Number(p.stock);
  return n > 0 ? Math.floor(n) : 0;
}

// "in" = còn hàng, "low" = sắp hết, "out" = hết hàng
export function stockState(p) {
  const n = stockOf(p);
  if (n === 0) return "out";
  if (n < LOW_STOCK) return "low";
  return "in";
}

// Nhãn nhỏ hiện trên thẻ món / bảng admin
export function stockBadge(p) {
  const n = stockOf(p);
  const s = stockState(p);
  if (s === "out") return `<span class="stock out">Hết hàng</span>`;
  if (s === "low") return `<span class="stock low">⚠ Tồn kho sắp hết · còn ${n}</span>`;
  return `<span class="stock in">Còn hàng · ${n}</span>`;
}

// Sắp xếp: món dưới 10 nhảy lên đầu (ít nhất đứng trước).
// outLast = true  : (khách) món hết hàng xuống cuối cho dễ chọn
// outLast = false : (admin) món hết hàng đứng ĐẦU vì cần nhập thêm gấp
export function sortLowFirst(list, outLast) {
  function rank(p) {
    const s = stockState(p);
    if (s === "low") return 0;
    if (s === "out") return outLast ? 2 : 0;
    return 1;
  }
  // map + index để sắp xếp ổn định (giữ thứ tự cũ với món cùng nhóm)
  return list
    .map(function (p, i) { return { p: p, i: i }; })
    .sort(function (a, b) {
      const ra = rank(a.p), rb = rank(b.p);
      if (ra !== rb) return ra - rb;
      if (ra === 0) {
        const d = stockOf(a.p) - stockOf(b.p);
        if (d !== 0) return d;
      }
      return a.i - b.i;
    })
    .map(function (x) { return x.p; });
}

// Lọc theo trạng thái: "" = tất cả, "in" = còn hàng (gồm cả sắp hết), "low" = sắp hết, "out" = hết hàng
export function matchStock(p, filter) {
  if (filter === "") return true;
  if (filter === "in") return stockOf(p) > 0;
  if (filter === "low") return stockState(p) === "low";
  if (filter === "out") return stockOf(p) === 0;
  return true;
}

// Tìm sản phẩm của 1 dòng trong đơn (đơn cũ chưa có productId thì tìm theo tên)
function productOfItem(it) {
  for (let i = 0; i < db.products.length; i++) {
    if (it.productId ? db.products[i].id === it.productId : db.products[i].name === it.name) return db.products[i];
  }
  return null;
}

// Trừ kho khi đặt đơn
export function deductStock(order) {
  for (let i = 0; i < order.items.length; i++) {
    const p = productOfItem(order.items[i]);
    if (p) p.stock = Math.max(0, stockOf(p) - order.items[i].qty);
  }
}

// Hoàn kho khi đơn bị hủy
export function restoreStock(order) {
  for (let i = 0; i < order.items.length; i++) {
    const p = productOfItem(order.items[i]);
    if (p) p.stock = stockOf(p) + order.items[i].qty;
  }
}

// Tổng số ly của 1 sản phẩm đang có trong giỏ (mọi size cộng lại, vì chung 1 kho)
export function qtyInCart(cart, productId) {
  let n = 0;
  for (let i = 0; i < cart.length; i++) {
    if (cart[i].productId === productId) n += cart[i].qty;
  }
  return n;
}
