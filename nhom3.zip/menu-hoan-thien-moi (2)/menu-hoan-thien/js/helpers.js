/* =====================================================================
   FILE: helpers.js - CÁC HÀM NHỎ DÙNG CHUNG
   File này không import gì cả, nên file nào cũng import nó được.
   Mỗi hàm làm đúng 1 việc nhỏ. Chữ "export" = cho phép file khác dùng hàm này.
   ===================================================================== */

// Các trạng thái của đơn hàng
export const ORDER_STATUSES = ["Chờ xác nhận", "Đang chuẩn bị", "Đang giao", "Hoàn thành", "Đã hủy"];

/* ---------- Đọc file HTML ---------- */

// Mỗi file HTML đọc 1 lần rồi nhớ lại ở đây, lần sau khỏi đọc nữa
const htmlCache = {};

// Đọc 1 file HTML trong thư mục html/. Ví dụ: await loadHTML("html/pages/home.html")
// Lưu ý: đường dẫn tính từ index.html (không phải từ file js)
export async function loadHTML(path) {
  if (htmlCache[path]) return htmlCache[path];

  const res = await fetch(path);
  if (!res.ok) throw new Error("Không tìm thấy file " + path);
  const text = await res.text();

  htmlCache[path] = text;
  return text;
}

// Điền dữ liệu vào chỗ {{tên}} trong file HTML.
// Ví dụ: fill("<h1>{{title}}</h1>", { title: "Xin chào" })  ->  "<h1>Xin chào</h1>"
export function fill(template, data) {
  return template.replace(/\{\{(\w+)\}\}/g, function (match, key) {
    if (data[key] !== undefined) return String(data[key]);
    return match; // không có dữ liệu cho {{tên}} này thì để nguyên (dễ phát hiện lỗi gõ sai tên)
  });
}

/* ---------- Hàm nhỏ ---------- */

// Lấy phần tử HTML theo id.   Ví dụ: $("app")
export function $(id) {
  return document.getElementById(id);
}

// 59000 -> "59.000 đ"
export function formatPrice(n) {
  return n.toLocaleString("vi-VN") + " đ";
}

// Chặn mã HTML độc hại. Dùng cho chữ do NGƯỜI DÙNG nhập khi in ra màn hình.
export function safe(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Hiện thông báo nhỏ dưới màn hình trong 2 giây
export function toast(msg) {
  const old = document.querySelector(".toast");
  if (old) old.remove();
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function () {
    t.remove();
  }, 2000);
}

// Tạo id mới = id lớn nhất đang có + 1
export function nextId(list) {
  let max = 0;
  for (let i = 0; i < list.length; i++) {
    if (list[i].id > max) max = list[i].id;
  }
  return max + 1;
}

// Tìm 1 phần tử trong danh sách theo id (không có thì trả về null)
export function findById(list, id) {
  for (let i = 0; i < list.length; i++) {
    if (list[i].id === id) return list[i];
  }
  return null;
}

// Bỏ dấu + chữ thường để tìm kiếm: "Trà Sữa" -> "tra sua"
export function norm(text) {
  return String(text)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .trim();
}

// "0912 345.678" -> "0912345678"
export function cleanPhone(text) {
  return String(text).replace(/[\s.\-]/g, "");
}

// Số điện thoại VN: 10 số, bắt đầu bằng 03, 05, 07, 08 hoặc 09
export function phoneOK(phone) {
  return /^0(3|5|7|8|9)\d{8}$/.test(phone);
}

// Hiện dòng lỗi đỏ dưới form (form phải có sẵn <div class="form-error">)
export function showError(form, msg) {
  const box = form.querySelector(".form-error");
  box.textContent = msg;
  box.classList.add("show");
}

// Giá thấp nhất trong các size của 1 món
export function minPrice(p) {
  let min = p.sizes[0].price;
  for (let i = 1; i < p.sizes.length; i++) {
    if (p.sizes[i].price < min) min = p.sizes[i].price;
  }
  return min;
}

// Nhãn màu cho trạng thái đơn (màu do CSS lo: st-0, st-1, ...)
export function statusTag(status) {
  return `<em class="st st-${ORDER_STATUSES.indexOf(status)}">${safe(status)}</em>`;
}

// Dãy nút số trang: 1 2 3 ...
// total = tổng số mục, page = trang hiện tại, perPage = số mục mỗi trang, act = tên hành động khi bấm
export function pagerHTML(total, page, perPage, act) {
  const pageCount = Math.ceil(total / perPage);
  if (pageCount <= 1) return "";
  let html = "";
  for (let i = 1; i <= pageCount; i++) {
    const on = i === page ? "on" : "";
    html += `<button class="${on}" data-act="${act}" data-page="${i}">${i}</button>`;
  }
  return `<div class="pager">${html}</div>`;
}

/* ---------- Hộp thoại (modal) ---------- */

// Hộp thoại nhỏ nổi lên giữa màn hình (dùng cho form thêm / sửa của admin)
export async function openModal(title, body) {
  const html = fill(await loadHTML("html/components/modal.html"), { title: title, body: body });
  closeModal(); // đóng hộp cũ (nếu có) rồi mới mở hộp mới
  const m = document.createElement("div");
  m.className = "modal";
  m.id = "modal";
  m.innerHTML = html;
  document.body.appendChild(m);
}

export function closeModal() {
  if ($("modal")) $("modal").remove();
}

/* ---------- Chuyển trang / vẽ lại trang ---------- */
// Hai hàm này chỉ "gửi tín hiệu" cho router.js (router tự lắng nghe).
// Làm vậy để file này không phải import router.js -> tránh import vòng tròn.

// Chuyển sang trang khác. Ví dụ: goto("#/home")
export function goto(hash) {
  if (location.hash === hash) {
    window.dispatchEvent(new Event("hashchange")); // đang ở đúng trang đó rồi thì vẽ lại
  } else {
    location.hash = hash;
  }
}

// Vẽ lại trang hiện tại (giữ nguyên vị trí cuộn). Gọi sau khi thay đổi dữ liệu.
export function refresh() {
  window.dispatchEvent(new Event("refresh"));
}
