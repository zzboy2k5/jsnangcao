/* =====================================================================
   FILE: admin/admin.js - KHUNG TRANG QUẢN TRỊ (chỉ admin mới vào được)
   Bố cục: menu bên trái + nội dung bên phải. Có 5 tab, mỗi tab 1 file js riêng:
     Tổng quan (dashboard.js) | Danh mục (categories.js) | Sản phẩm (products.js)
     Đơn hàng (orders.js)     | Khách hàng (users.js)
   HTML khung: html/admin/layout.html
   ===================================================================== */

import { loadHTML, fill, safe } from "../helpers.js";
import { me, isAdmin } from "../data.js";
import { adminDashboard } from "./dashboard.js";
import { adminCategories } from "./categories.js";
import { adminProducts } from "./products.js";
import { adminOrders } from "./orders.js";
import { adminUsers } from "./users.js";

// Bảng tra: tên tab -> hàm vẽ tab
const adminPages = {
  dashboard: adminDashboard,
  categories: adminCategories,
  products: adminProducts,
  orders: adminOrders,
  users: adminUsers
};

// name = phần sau # trong địa chỉ, ví dụ "admin" hoặc "admin/products"
export async function pageAdmin(name) {
  if (!isAdmin()) {
    return await loadHTML("html/pages/no-permission.html");
  }

  let tab = name.split("/")[1] || "dashboard";
  if (!adminPages[tab]) tab = "dashboard";

  // Tab nào đang mở thì có chữ "active" (để tô màu trong menu bên trái)
  const active = { dashboard: "", categories: "", products: "", orders: "", users: "" };
  active[tab] = "active";

  const layout = await loadHTML("html/admin/layout.html");
  return fill(layout, {
    name: safe(me.name),
    content: await adminPages[tab](),
    dashboard: active.dashboard,
    categories: active.categories,
    products: active.products,
    orders: active.orders,
    users: active.users
  });
}
