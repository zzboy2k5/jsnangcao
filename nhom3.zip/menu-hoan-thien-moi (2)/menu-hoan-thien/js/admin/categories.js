/* =====================================================================
   FILE: admin/categories.js - TAB DANH MỤC
   HTML: html/admin/categories.html, category-row.html, category-form.html
   ===================================================================== */

import { loadHTML, fill, safe, norm, nextId, findById, showError, toast, openModal, closeModal, refresh } from "../helpers.js";
import { db, saveDB } from "../data.js";
import { actions, forms } from "../events.js";

export async function adminCategories() {
  const rowTemplate = await loadHTML("html/admin/category-row.html");
  let rows = "";
  for (let i = 0; i < db.categories.length; i++) {
    const c = db.categories[i];

    // Đếm số sản phẩm thuộc danh mục này
    let count = 0;
    for (let j = 0; j < db.products.length; j++) {
      if (db.products[j].categoryId === c.id) count++;
    }

    rows += fill(rowTemplate, { stt: i + 1, id: c.id, name: safe(c.name), count: count });
  }
  if (rows === "") {
    rows = fill(await loadHTML("html/components/empty-row.html"), { cols: 4, text: "Chưa có danh mục nào." });
  }

  const page = await loadHTML("html/admin/categories.html");
  return fill(page, { rows: rows });
}

// Form thêm / sửa danh mục (c = null nghĩa là thêm mới)
async function categoryFormHTML(c) {
  const template = await loadHTML("html/admin/category-form.html");
  return fill(template, { id: c ? c.id : "", name: c ? safe(c.name) : "" });
}

actions.addCat = async function () {
  openModal("Thêm danh mục", await categoryFormHTML(null));
};

actions.editCat = async function (el) {
  const c = findById(db.categories, Number(el.dataset.id));
  openModal("Sửa danh mục", await categoryFormHTML(c));
};

actions.delCat = function (el) {
  const id = Number(el.dataset.id);
  for (let i = 0; i < db.products.length; i++) {
    if (db.products[i].categoryId === id) return toast("Danh mục còn sản phẩm, hãy xóa hoặc chuyển sản phẩm trước");
  }
  if (!confirm("Xóa danh mục này?")) return;
  // filter = giữ lại những phần tử thỏa điều kiện (ở đây: khác id cần xóa)
  db.categories = db.categories.filter(function (c) {
    return c.id !== id;
  });
  saveDB();
  refresh();
};

forms.categoryForm = function (f) {
  const name = f.name.value.trim();
  const id = Number(f.id.value); // 0 = thêm mới

  if (name === "") return showError(f, "Vui lòng nhập tên danh mục");
  if (norm(name) === "tat ca") return showError(f, 'Không được đặt tên "Tất cả" (tên này dành cho bộ lọc)');
  for (let i = 0; i < db.categories.length; i++) {
    if (norm(db.categories[i].name) === norm(name) && db.categories[i].id !== id) {
      return showError(f, "Tên danh mục đã tồn tại");
    }
  }

  if (id) findById(db.categories, id).name = name;
  else db.categories.push({ id: nextId(db.categories), name: name });

  saveDB();
  closeModal();
  toast("Đã lưu danh mục ✅");
  refresh();
};
