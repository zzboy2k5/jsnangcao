/* =====================================================================
   FILE: admin/products.js - TAB SẢN PHẨM (tìm kiếm + lọc danh mục + phân trang)
   HTML: html/admin/products.html, product-table.html, product-row.html, product-form.html
   ===================================================================== */

import { $, loadHTML, fill, safe, norm, nextId, findById, formatPrice, showError, toast, openModal, closeModal, pagerHTML, refresh } from "../helpers.js";
import { db, saveDB, categoryName } from "../data.js";
import { actions, forms, inputs, changes } from "../events.js";
import { stockOf, stockState, stockBadge, matchStock, sortLowFirst } from "../stock.js";

const PER_PAGE = 8;             // bảng sản phẩm hiện 8 dòng mỗi trang
let page = 1;                   // trang hiện tại của bảng sản phẩm
let keyword = "";               // chữ trong ô tìm kiếm
let filterStock = "";           // lọc tồn kho ("" = tất cả, "in", "low", "out")
let filterCat = "0";            // danh mục đang lọc ("0" = tất cả)
let pendingImg = "";            // ảnh đang chọn trong form thêm / sửa sản phẩm

/* ---------- Bảng sản phẩm ---------- */

// Bảng sản phẩm. Tách riêng để khi gõ tìm kiếm chỉ vẽ lại bảng (ô tìm kiếm không bị mất con trỏ)
async function productTable() {
  const q = norm(keyword);
  const cat = Number(filterCat);

  // Lọc sản phẩm theo tên + danh mục
  let list = [];
  for (let i = 0; i < db.products.length; i++) {
    const p = db.products[i];
    if (norm(p.name).includes(q) && (cat === 0 || p.categoryId === cat) && matchStock(p, filterStock)) list.push(p);
  }
  // Món dưới 10 (kể cả hết hàng) nhảy lên đầu để admin nhập thêm
  list = sortLowFirst(list, false);

  // Cắt đúng các dòng của trang hiện tại
  const maxPage = Math.max(1, Math.ceil(list.length / PER_PAGE));
  if (page > maxPage) page = maxPage;
  const start = (page - 1) * PER_PAGE;
  const part = list.slice(start, start + PER_PAGE);

  const rowTemplate = await loadHTML("html/admin/product-row.html");
  let rows = "";
  for (let i = 0; i < part.length; i++) {
    const p = part[i];
    let sizes = "";
    for (let j = 0; j < p.sizes.length; j++) {
      sizes += (j > 0 ? "<br>" : "") + safe(p.sizes[j].size) + " " + formatPrice(p.sizes[j].price);
    }
    rows += fill(rowTemplate, {
      id: p.id,
      img: p.img,
      name: safe(p.name),
      category: safe(categoryName(p.categoryId)),
      sizes: sizes,
      stock: stockBadge(p),
      rowClass: stockState(p) === "in" ? "" : "low-row",
      onClass: p.hidden ? "" : "on",
      hiddenText: p.hidden ? "Đang ẩn" : "Đang bán"
    });
  }
  if (rows === "") {
    rows = fill(await loadHTML("html/components/empty-row.html"), { cols: 7, text: "Không có sản phẩm phù hợp." });
  }

  const template = await loadHTML("html/admin/product-table.html");
  return fill(template, { rows: rows, pager: pagerHTML(list.length, page, PER_PAGE, "adminPage") });
}

export async function adminProducts() {
  let categoryOptions = "";
  for (let i = 0; i < db.categories.length; i++) {
    const c = db.categories[i];
    categoryOptions += `<option value="${c.id}" ${String(c.id) === filterCat ? "selected" : ""}>${safe(c.name)}</option>`;
  }

  const template = await loadHTML("html/admin/products.html");
  return fill(template, {
    count: db.products.length,
    keyword: safe(keyword),
    categoryOptions: categoryOptions,
    stockOptions: [["", "Tất cả tồn kho"], ["in", "Còn hàng"], ["low", "Sắp hết (dưới 10)"], ["out", "Hết hàng"]].map(function (o) {
      return `<option value="${o[0]}" ${o[0] === filterStock ? "selected" : ""}>${o[1]}</option>`;
    }).join(""),
    table: await productTable()
  });
}

// Gõ vào ô tìm kiếm sản phẩm
inputs.prodSearch = async function (el) {
  keyword = el.value;
  page = 1;
  $("adTable").innerHTML = await productTable();
};

// Chọn danh mục để lọc
changes.prodCat = async function (el) {
  filterCat = el.value;
  page = 1;
  $("adTable").innerHTML = await productTable();
};

// Lọc theo tồn kho
changes.prodStock = async function (el) {
  filterStock = el.value;
  page = 1;
  $("adTable").innerHTML = await productTable();
};

// Bấm số trang của bảng sản phẩm
actions.adminPage = function (el) {
  page = Number(el.dataset.page);
  refresh();
};

/* ---------- Form thêm / sửa sản phẩm ---------- */

// p = sản phẩm cần sửa (null = thêm mới), catId = danh mục chọn sẵn
async function productFormHTML(p, catId) {
  // Danh sách ảnh có sẵn (không lấy ảnh do admin tự tải lên)
  const imgs = [];
  for (let i = 0; i < db.products.length; i++) {
    const img = db.products[i].img;
    if (!img.startsWith("data:") && !imgs.includes(img)) imgs.push(img);
  }

  // Sản phẩm mới thì dùng giá trị mặc định
  const cur = p || {
    id: "", name: "", categoryId: catId || (db.categories[0] ? db.categories[0].id : 0),
    img: "", desc: "", temps: ["Lạnh"], hidden: false, stock: 30,
    sizes: [{ size: "M", ml: "500ml", price: 45000 }, { size: "L", ml: "700ml", price: 53000 }]
  };
  pendingImg = cur.img; // nhớ ảnh đang chọn (đổi khi admin chọn ảnh khác)

  let tempOptions = "";
  const tempList = ["Nóng,Lạnh", "Lạnh", "Nóng", "Thường"];
  for (let i = 0; i < tempList.length; i++) {
    tempOptions += `<option ${tempList[i] === cur.temps.join(",") ? "selected" : ""}>${tempList[i]}</option>`;
  }

  let categoryOptions = "";
  for (let i = 0; i < db.categories.length; i++) {
    const c = db.categories[i];
    categoryOptions += `<option value="${c.id}" ${c.id === cur.categoryId ? "selected" : ""}>${safe(c.name)}</option>`;
  }

  let imgOptions = "";
  for (let i = 0; i < imgs.length; i++) {
    const label = imgs[i].replace("img/", "").replace(".svg", "");
    imgOptions += `<option value="${imgs[i]}" ${imgs[i] === cur.img ? "selected" : ""}>${label}</option>`;
  }

  // Mỗi size viết trên 1 dòng:  M|500ml|45000
  const sizeLines = [];
  for (let i = 0; i < cur.sizes.length; i++) {
    sizeLines.push(cur.sizes[i].size + "|" + cur.sizes[i].ml + "|" + cur.sizes[i].price);
  }

  const template = await loadHTML("html/admin/product-form.html");
  return fill(template, {
    id: cur.id,
    name: safe(cur.name),
    categoryOptions: categoryOptions,
    desc: safe(cur.desc),
    tempOptions: tempOptions,
    sizes: sizeLines.join("\n"),
    stock: stockOf(cur),
    img: cur.img,
    previewStyle: cur.img ? "" : 'style="visibility:hidden"',
    imgOptions: imgOptions,
    checked: cur.hidden ? "" : "checked"
  });
}

// Xem trước ảnh trong form sản phẩm
function showPreview(src) {
  const img = $("pPreview");
  img.src = src;
  img.style.visibility = "visible";
}

// Thu nhỏ ảnh người dùng chọn (tối đa 480px) rồi đổi thành chuỗi chữ để lưu vào localStorage.
// done(dữ_liệu) được gọi khi xử lý xong. Chuỗi rỗng "" nghĩa là lỗi.
function readImageFile(file, done) {
  const reader = new FileReader();
  reader.onload = function () {
    const img = new Image();
    img.onload = function () {
      const scale = Math.min(1, 480 / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      done(canvas.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = function () {
      done("");
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

// Chọn ảnh có sẵn trong danh sách
changes.prodImgSel = function (el) {
  if (el.value === "") return;
  pendingImg = el.value;
  showPreview(pendingImg);
  document.querySelector('[data-chg="prodFile"]').value = ""; // xóa file đã chọn trước đó
};

// Tải ảnh từ máy
changes.prodFile = function (el) {
  const file = el.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) return showError($("productForm"), "Vui lòng chọn một file ảnh");

  readImageFile(file, function (data) {
    if (data === "") return showError($("productForm"), "Không đọc được ảnh này");
    pendingImg = data;
    showPreview(data);
    document.querySelector('[data-chg="prodImgSel"]').value = "";
  });
};

actions.addProduct = async function (el) {
  // Chọn sẵn danh mục đang lọc ở tab Sản phẩm
  const catId = Number(filterCat) || 0;
  openModal("Thêm sản phẩm", await productFormHTML(null, catId));
};

actions.editProduct = async function (el) {
  const p = findById(db.products, Number(el.dataset.id));
  openModal("Sửa sản phẩm", await productFormHTML(p, 0));
};

// Nút "Đang bán / Đang ẩn": đổi qua lại
actions.hideProduct = function (el) {
  const p = findById(db.products, Number(el.dataset.id));
  p.hidden = !p.hidden;
  saveDB();
  refresh();
};

actions.delProduct = function (el) {
  if (!confirm("Xóa sản phẩm này?")) return;
  const id = Number(el.dataset.id);
  db.products = db.products.filter(function (p) {
    return p.id !== id;
  });
  saveDB();
  refresh();
};

// Gửi form sản phẩm: kiểm tra dữ liệu rồi lưu
forms.productForm = function (f) {
  const name = f.name.value.trim().replace(/\s+/g, " ");
  const id = Number(f.id.value); // 0 = thêm mới

  if (pendingImg === "") return showError(f, "Vui lòng chọn hoặc tải lên ảnh sản phẩm");
  if (name === "") return showError(f, "Vui lòng nhập tên sản phẩm");
  for (let i = 0; i < db.products.length; i++) {
    if (db.products[i].id !== id && norm(db.products[i].name) === norm(name)) {
      return showError(f, "Đã có sản phẩm trùng tên này");
    }
  }

  // Đọc từng dòng size: "M|500ml|45000"
  const sizes = [];
  const lines = f.sizes.value.split("\n");
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim() === "") continue;
    const x = lines[i].split("|");
    const price = Number(x[2]);
    if (x.length !== 3 || !(price >= 1000) || price > 10000000) {
      return showError(f, "Size phải viết dạng: M|500ml|45000 (giá từ 1.000 đến 10.000.000)");
    }
    sizes.push({ size: x[0].trim(), ml: x[1].trim(), price: price });
  }
  if (sizes.length === 0) return showError(f, "Cần ít nhất 1 size");

  const stock = Number(f.stock.value);
  if (f.stock.value.trim() === "" || !Number.isInteger(stock) || stock < 0 || stock > 99999) {
    return showError(f, "Số lượng tồn kho phải là số nguyên từ 0 đến 99.999");
  }

  const data = {
    stock: stock,
    name: name,
    categoryId: Number(f.categoryId.value),
    img: pendingImg,
    desc: f.desc.value.trim(),
    temps: f.temps.value.split(","),
    sizes: sizes,
    hidden: !f.show.checked
  };

  if (id) {
    Object.assign(findById(db.products, id), data); // sửa: chép các giá trị mới đè lên sản phẩm cũ
  } else {
    data.id = nextId(db.products);
    db.products.push(data);
  }

  // localStorage có thể đầy nếu ảnh quá nặng
  if (!saveDB()) return showError(f, "Không lưu được. Ảnh có thể quá lớn, hãy chọn ảnh khác");
  closeModal();
  toast("Đã lưu sản phẩm ✅");
  refresh();
};
