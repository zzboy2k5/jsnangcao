/* =====================================================================
   FILE: admin/dashboard.js - TAB TỔNG QUAN
   HTML: html/admin/dashboard.html, dashboard-row.html
   ===================================================================== */

import { loadHTML, fill, safe, formatPrice, statusTag } from "../helpers.js";
import { db } from "../data.js";
import { actions } from "../events.js";

export async function adminDashboard() {
  // Duyệt qua đơn hàng để đếm
  let revenue = 0; // doanh thu = tổng tiền các đơn "Hoàn thành"
  let waiting = 0; // số đơn đang chờ xác nhận
  for (let i = 0; i < db.orders.length; i++) {
    if (db.orders[i].status === "Hoàn thành") revenue += db.orders[i].total;
    if (db.orders[i].status === "Chờ xác nhận") waiting++;
  }

  // 5 đơn mới nhất
  const rowTemplate = await loadHTML("html/admin/dashboard-row.html");
  let rows = "";
  for (let i = 0; i < 5 && i < db.orders.length; i++) {
    const o = db.orders[i];
    rows += fill(rowTemplate, {
      code: o.code,
      name: safe(o.name),
      time: o.time,
      total: formatPrice(o.total),
      status: statusTag(o.status)
    });
  }
  if (rows === "") {
    rows = fill(await loadHTML("html/components/empty-row.html"), { cols: 5, text: "Chưa có đơn hàng nào." });
  }

  const page = await loadHTML("html/admin/dashboard.html");
  return fill(page, {
    revenue: formatPrice(revenue),
    orderCount: db.orders.length,
    waiting: waiting,
    productCount: db.products.length,
    categoryCount: db.categories.length,
    customerCount: db.users.length, // db.users chỉ chứa khách hàng (admin viết cứng riêng)
    rows: rows
  });
}

actions.resetData = function () {
  if (!confirm("Xóa TOÀN BỘ dữ liệu (kể cả tài khoản, đơn hàng) và về dữ liệu mẫu?")) return;
  localStorage.clear();
  location.hash = "#/home";
  location.reload();
};
