/* =====================================================================
   FILE: admin/orders.js - TAB ĐƠN HÀNG (tìm kiếm + lọc trạng thái)
   HTML: html/admin/orders.html, order-table.html, order-row.html, order-detail.html, order-line.html
   ===================================================================== */

import { $, loadHTML, fill, safe, norm, findById, formatPrice, statusTag, toast, openModal, refresh, ORDER_STATUSES } from "../helpers.js";
import { db, saveDB } from "../data.js";
import { actions, inputs, changes } from "../events.js";
import { restoreStock, deductStock } from "../stock.js";

let keyword = "";       // chữ trong ô tìm kiếm
let filterStatus = "";  // trạng thái đang lọc ("" = tất cả)

async function orderTable() {
  const q = norm(keyword);
  const rowTemplate = await loadHTML("html/admin/order-row.html");
  let rows = "";

  for (let i = 0; i < db.orders.length; i++) {
    const o = db.orders[i];
    if (!norm(o.code + " " + o.name + " " + o.phone).includes(q)) continue;
    if (filterStatus !== "" && o.status !== filterStatus) continue;

    // Ô chọn trạng thái cho từng đơn
    let statusOptions = "";
    for (let j = 0; j < ORDER_STATUSES.length; j++) {
      statusOptions += `<option ${ORDER_STATUSES[j] === o.status ? "selected" : ""}>${ORDER_STATUSES[j]}</option>`;
    }

    rows += fill(rowTemplate, {
      id: o.id,
      code: o.code,
      name: safe(o.name),
      phone: safe(o.phone),
      time: o.time,
      total: formatPrice(o.total),
      statusClass: "st-" + ORDER_STATUSES.indexOf(o.status),
      statusOptions: statusOptions
    });
  }
  if (rows === "") {
    rows = fill(await loadHTML("html/components/empty-row.html"), { cols: 6, text: "Không có đơn hàng phù hợp." });
  }

  const template = await loadHTML("html/admin/order-table.html");
  return fill(template, { rows: rows });
}

export async function adminOrders() {
  let statusOptions = "";
  for (let i = 0; i < ORDER_STATUSES.length; i++) {
    const s = ORDER_STATUSES[i];
    statusOptions += `<option ${s === filterStatus ? "selected" : ""}>${s}</option>`;
  }

  const template = await loadHTML("html/admin/orders.html");
  return fill(template, {
    count: db.orders.length,
    keyword: safe(keyword),
    statusOptions: statusOptions,
    table: await orderTable()
  });
}

inputs.ordSearch = async function (el) {
  keyword = el.value;
  $("adTable").innerHTML = await orderTable();
};

changes.ordFilter = async function (el) {
  filterStatus = el.value;
  $("adTable").innerHTML = await orderTable();
};

// Đổi trạng thái 1 đơn
changes.orderStatus = function (el) {
  const o = findById(db.orders, Number(el.dataset.id));
  const old = o.status;
  o.status = el.value;
  // Hủy đơn -> trả hàng về kho. Mở lại đơn đã hủy -> trừ kho lại.
  if (old !== "Đã hủy" && o.status === "Đã hủy") restoreStock(o);
  if (old === "Đã hủy" && o.status !== "Đã hủy") deductStock(o);
  saveDB();
  el.className = "st-sel st-" + ORDER_STATUSES.indexOf(o.status); // đổi màu ô chọn theo trạng thái mới
  toast("Đã cập nhật trạng thái ✅");
};

// Xem chi tiết đơn
actions.viewOrder = async function (el) {
  const o = findById(db.orders, Number(el.dataset.id));

  const lineTemplate = await loadHTML("html/admin/order-line.html");
  let lines = "";
  for (let i = 0; i < o.items.length; i++) {
    const it = o.items[i];
    lines += fill(lineTemplate, {
      name: safe(it.name),
      size: safe(it.size),
      qty: it.qty,
      lineTotal: formatPrice(it.price * it.qty)
    });
  }

  const detail = fill(await loadHTML("html/admin/order-detail.html"), {
    name: safe(o.name),
    phone: safe(o.phone),
    address: safe(o.address),
    note: safe(o.note || "(không có)"),
    time: o.time,
    status: statusTag(o.status),
    lines: lines,
    ship: formatPrice(o.ship),
    total: formatPrice(o.total)
  });
  openModal("Đơn hàng " + o.code, detail);
};

actions.delOrder = function (el) {
  const o = findById(db.orders, Number(el.dataset.id));
  if (!confirm("Xóa đơn " + o.code + "? Không thể khôi phục.")) return;
  db.orders = db.orders.filter(function (x) {
    return x.id !== o.id;
  });
  saveDB();
  toast("Đã xóa đơn hàng");
  refresh();
};
