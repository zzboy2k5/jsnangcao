/* =====================================================================
   FILE: admin/users.js - TAB KHÁCH HÀNG
   Chỉ quản lý KHÁCH HÀNG. Admin viết cứng trong data.js nên không có trong danh sách này.
   Không còn phân quyền: ai tạo mới cũng là khách hàng.
   HTML: html/admin/users.html, user-table.html, user-row.html, user-form.html, user-edit-form.html
   ===================================================================== */

import { $, loadHTML, fill, safe, norm, nextId, findById, formatPrice, cleanPhone, phoneOK, showError, toast, openModal, closeModal, refresh } from "../helpers.js";
import { db, saveDB, phoneExists, newUserId } from "../data.js";
import { actions, forms, inputs } from "../events.js";

let keyword = ""; // chữ trong ô tìm kiếm

async function userTable() {
  const q = norm(keyword);
  const rowTemplate = await loadHTML("html/admin/user-row.html");
  let rows = "";

  for (let i = 0; i < db.users.length; i++) {
    const u = db.users[i];
    if (!norm(u.name + " " + u.phone).includes(q)) continue;

    // Đếm đơn + tổng tiền đã chi (đơn hoàn thành) của người này
    let orderCount = 0;
    let spent = 0;
    for (let j = 0; j < db.orders.length; j++) {
      if (db.orders[j].userId !== u.id) continue;
      orderCount++;
      if (db.orders[j].status === "Hoàn thành") spent += db.orders[j].total;
    }

    rows += fill(rowTemplate, {
      id: u.id,
      name: safe(u.name),
      phone: safe(u.phone),
      statusClass: u.locked ? "st-4" : "st-3",
      statusText: u.locked ? "Bị khóa" : "Hoạt động",
      orderCount: orderCount,
      spent: formatPrice(spent),
      lockText: u.locked ? "Mở khóa" : "Khóa"
    });
  }
  if (rows === "") {
    rows = fill(await loadHTML("html/components/empty-row.html"), { cols: 5, text: "Chưa có khách hàng nào." });
  }

  const template = await loadHTML("html/admin/user-table.html");
  return fill(template, { rows: rows });
}

export async function adminUsers() {
  const template = await loadHTML("html/admin/users.html");
  return fill(template, {
    count: db.users.length,
    keyword: safe(keyword),
    table: await userTable()
  });
}

inputs.userSearch = async function (el) {
  keyword = el.value;
  $("adTable").innerHTML = await userTable();
};

actions.addUser = async function () {
  openModal("Thêm tài khoản khách hàng", await loadHTML("html/admin/user-form.html"));
};

// Sửa họ tên + số điện thoại
actions.editUser = async function (el) {
  const u = findById(db.users, Number(el.dataset.id));
  const form = fill(await loadHTML("html/admin/user-edit-form.html"), {
    id: u.id,
    name: safe(u.name),
    phone: safe(u.phone)
  });
  openModal("Sửa thông tin khách hàng", form);
};

actions.lockUser = function (el) {
  const u = findById(db.users, Number(el.dataset.id));
  u.locked = !u.locked;
  saveDB();
  refresh();
};

actions.delUser = function (el) {
  const u = findById(db.users, Number(el.dataset.id));
  if (!confirm("Xóa tài khoản " + u.name + "? (đơn hàng cũ vẫn được giữ)")) return;
  db.users = db.users.filter(function (x) {
    return x.id !== u.id;
  });
  saveDB();
  refresh();
};

// Tạo khách hàng mới (role luôn là "user")
forms.userForm = function (f) {
  const name = f.name.value.trim();
  const phone = cleanPhone(f.phone.value);
  if (name.length < 2) return showError(f, "Vui lòng nhập họ tên");
  if (!phoneOK(phone)) return showError(f, "Số điện thoại chưa đúng (10 số)");
  if (phoneExists(phone, 0)) return showError(f, "Số điện thoại này đã có tài khoản");
  if (f.password.value.length < 6) return showError(f, "Mật khẩu phải có ít nhất 6 ký tự");

  db.users.push({
    id: newUserId(),
    address: "",
    name: name,
    phone: phone,
    password: f.password.value,
    role: "user",
    locked: false,
    created: new Date().toLocaleDateString("vi-VN")
  });
  saveDB();
  closeModal();
  toast("Đã tạo tài khoản ✅");
  refresh();
};

forms.userEditForm = function (f) {
  const id = Number(f.id.value);
  const name = f.name.value.trim();
  const phone = cleanPhone(f.phone.value);
  if (name.length < 2) return showError(f, "Vui lòng nhập họ tên");
  if (!phoneOK(phone)) return showError(f, "Số điện thoại chưa đúng (10 số)");
  if (phoneExists(phone, id)) return showError(f, "Số điện thoại này đã được người khác sử dụng");

  const u = findById(db.users, id);
  u.name = name;
  u.phone = phone;
  saveDB();
  closeModal();
  toast("Đã cập nhật thông tin ✅");
  refresh();
};
