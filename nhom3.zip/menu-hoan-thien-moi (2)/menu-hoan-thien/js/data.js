/* =====================================================================
   FILE: data.js - DỮ LIỆU CỦA WEB
   - db  : chứa mọi dữ liệu (sản phẩm, khách hàng, đơn hàng...)
   - me  : người đang đăng nhập (null = chưa đăng nhập)
   - ADMIN: tài khoản quản trị, VIẾT CỨNG ngay trong code (không nằm trong db)
   Dữ liệu lấy từ data.json ở lần mở đầu tiên, rồi lưu vào localStorage.
   localStorage là "kho nhỏ" của trình duyệt, tắt web mở lại vẫn còn.
   ===================================================================== */

import { toast } from "./helpers.js";

// Tài khoản admin cố định. Muốn đổi số điện thoại / mật khẩu admin thì sửa ngay tại đây.
export const ADMIN = {
  id: "admin",
  name: "Quản trị viên",
  phone: "0398497733",
  password: "admin123",
  role: "admin"
};

// "export let" để file khác đọc được giá trị mới nhất.
// File khác KHÔNG được gán lại (db = ...), muốn đổi thì gọi hàm trong file này.
export let db = null;
export let me = null;

// Lưu toàn bộ db vào localStorage. Gọi hàm này SAU MỖI LẦN thay đổi dữ liệu.
// Trả về true nếu lưu được, false nếu bộ nhớ trình duyệt đầy (thường do ảnh tải lên quá nặng).
export function saveDB() {
  try {
    localStorage.setItem("menu_db", JSON.stringify(db));
    return true;
  } catch (e) {
    toast("⚠️ Bộ nhớ trình duyệt đã đầy, chưa lưu được");
    return false;
  }
}

// Nạp dữ liệu. Trả về true nếu nạp được, false nếu lỗi.
export async function loadData() {
  // Bước 1: xem trong localStorage đã có dữ liệu chưa
  const saved = localStorage.getItem("menu_db");
  if (saved) {
    db = JSON.parse(saved);
    cleanOldData();
    return true;
  }

  // Bước 2: chưa có thì đọc từ data.json
  try {
    const res = await fetch("data.json");
    db = await res.json();
    saveDB();
    return true;
  } catch (e) {
    document.getElementById("app").innerHTML =
      "<h2 style='text-align:center;margin:60px'>⚠️ Không đọc được data.json.<br>" +
      "Hãy mở web bằng Live Server (VS Code) thay vì bấm đúp file.</h2>";
    return false;
  }
}

// Dữ liệu cũ (bản trước) còn lưu trong trình duyệt có chứa admin, tin nhắn, chatbot.
// Hàm này dọn những thứ đó đi cho gọn. Dữ liệu mới thì không có gì để dọn.
function cleanOldData() {
  let changed = false;

  // Bản cũ lưu admin trong db.users. Xóa admin đó VÀ xóa luôn đơn hàng mang id của admin,
  // nếu không khách mới đăng ký trùng id sẽ nhìn thấy đơn của admin.
  const adminIds = [];
  db.users = db.users.filter(function (u) {
    if (u.role === "admin") {
      adminIds.push(u.id);
      changed = true;
      return false;
    }
    return true;
  });
  const orderCount = db.orders.length;
  db.orders = db.orders.filter(function (o) {
    return adminIds.indexOf(o.userId) === -1 && o.userId !== "admin";
  });
  if (orderCount !== db.orders.length) changed = true;

  if (db.contacts || db.chatbot || db.chatUnknown) changed = true;
  delete db.contacts;
  delete db.chatbot;
  delete db.chatUnknown;

  // Sản phẩm cũ chưa có tồn kho thì cho mặc định 30
  for (let i = 0; i < db.products.length; i++) {
    if (typeof db.products[i].stock !== "number") {
      db.products[i].stock = 30;
      changed = true;
    }
  }

  // Bộ đếm id khách hàng: id đã dùng thì KHÔNG bao giờ dùng lại (kể cả khi khách bị xóa),
  // để khách mới không thể "thừa hưởng" đơn hàng cũ của người khác.
  let seq = db.userSeq || 1;
  for (let i = 0; i < db.users.length; i++) if (db.users[i].id >= seq) seq = db.users[i].id + 1;
  for (let i = 0; i < db.orders.length; i++) if (typeof db.orders[i].userId === "number" && db.orders[i].userId >= seq) seq = db.orders[i].userId + 1;
  if (db.userSeq !== seq) {
    db.userSeq = seq;
    changed = true;
  }

  if (changed) saveDB();
}

// Cấp id mới cho khách hàng (không bao giờ trùng, không dùng lại)
export function newUserId() {
  const id = db.userSeq || 1;
  db.userSeq = id + 1;
  return id;
}

/* ---------- Đăng nhập ---------- */

// Người đang đăng nhập có phải admin không?
export function isAdmin() {
  return me !== null && me.role === "admin";
}

// Mở web lên: xem ai đang đăng nhập.
// Trong localStorage ("menu_login") ta nhớ: chữ "admin", hoặc id của khách hàng.
export function checkLogin() {
  me = null;
  const saved = localStorage.getItem("menu_login");
  if (!saved) return;

  if (saved === "admin") {
    me = ADMIN;
    return;
  }
  for (let i = 0; i < db.users.length; i++) {
    if (db.users[i].id === Number(saved) && !db.users[i].locked) {
      me = db.users[i];
    }
  }
}

// Đăng nhập: nhớ người này lại
export function login(user) {
  me = user;
  localStorage.setItem("menu_login", user.id);
}

// Đăng xuất
export function logout() {
  me = null;
  localStorage.removeItem("menu_login");
}

/* ---------- Hàm tra cứu cần dùng db ---------- */

// Số điện thoại này đã có người đăng ký chưa? (exceptId = bỏ qua 1 người khi sửa thông tin)
export function phoneExists(phone, exceptId) {
  if (phone === ADMIN.phone) return true; // số của admin thì không ai được dùng
  for (let i = 0; i < db.users.length; i++) {
    if (db.users[i].phone === phone && db.users[i].id !== exceptId) return true;
  }
  return false;
}

// Danh mục Topping không hiện cho khách (trang chủ + thực đơn), chỉ admin quản lý
export function isToppingCategory(id) {
  for (let i = 0; i < db.categories.length; i++) {
    if (db.categories[i].id === id) return db.categories[i].name === "Topping";
  }
  return false;
}

// Tên danh mục từ id danh mục
export function categoryName(id) {
  for (let i = 0; i < db.categories.length; i++) {
    if (db.categories[i].id === id) return db.categories[i].name;
  }
  return "(đã xóa)";
}
