/* =====================================================================
   FILE: components.js - CÁC "THẺ" DÙNG LẠI Ở NHIỀU TRANG
   - Thẻ 1 món (trang chủ + thực đơn dùng chung)
   - Thẻ 1 bài tin tức (trang chủ + trang tin tức dùng chung)
   HTML nằm ở: html/components/product-card.html, news-card.html
   ===================================================================== */

import { loadHTML, fill, safe, formatPrice, minPrice } from "./helpers.js";
import { stockState, stockBadge } from "./stock.js";

// Thẻ 1 món. action = tên hành động khi bấm vào thẻ
export async function productCard(p, action) {
  const template = await loadHTML("html/components/product-card.html");
  return fill(template, {
    id: p.id,
    action: action,
    img: p.img,
    name: safe(p.name),
    price: formatPrice(minPrice(p)),
    stockClass: "is-" + stockState(p),
    stockBadge: stockBadge(p)
  });
}

// Thẻ 1 bài tin tức
export async function newsCard(n) {
  const template = await loadHTML("html/components/news-card.html");
  return fill(template, {
    id: n.id,
    img: n.img,
    tag: safe(n.tag),
    title: safe(n.title),
    date: n.date,
    summary: safe(n.summary)
  });
}
