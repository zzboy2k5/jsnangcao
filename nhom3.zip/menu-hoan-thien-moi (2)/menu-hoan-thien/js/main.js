/* =====================================================================
   FILE: main.js - KHỞI ĐỘNG - điểm bắt đầu của cả web
   index.html chỉ gọi đúng file này. Từ đây các file khác được "import" vào.
   Thứ tự: nạp dữ liệu -> xem ai đăng nhập -> vẽ footer -> vẽ trang hiện tại
   ===================================================================== */

import { loadData, checkLogin } from "./data.js";
import { renderFooter } from "./layout.js";
import { route } from "./router.js";
import "./events.js"; // chỉ cần file này chạy để bắt sự kiện, không lấy gì ra

async function start() {
  const ok = await loadData(); // chờ nạp xong dữ liệu
  if (!ok) return;             // nạp lỗi thì dừng

  checkLogin();
  await renderFooter();
  route();
}

start();
