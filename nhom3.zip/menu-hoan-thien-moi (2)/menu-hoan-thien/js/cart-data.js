/* =====================================================================
   FILE: cart-data.js - DỮ LIỆU GIỎ HÀNG (chưa có giao diện)
   Giỏ hàng của mỗi người được lưu riêng trong localStorage ("menu_cart_<id>").
   Mỗi dòng trong giỏ rất gọn:  { productId: 3, size: "M", qty: 2 }
   Khi cần hiện ra màn hình mới tra tên + giá từ db.products (hàm cartLines).
   Tách riêng file này để header (layout.js) và trang giỏ hàng (pages/cart.js) cùng dùng được.
   ===================================================================== */

import { db, me } from "./data.js";

export function getCart() {
  if (!me) return [];
  const text = localStorage.getItem("menu_cart_" + me.id);
  return text ? JSON.parse(text) : [];
}

export function setCart(cart) {
  localStorage.setItem("menu_cart_" + me.id, JSON.stringify(cart));
}

// Tổng số ly trong giỏ (hiện ở header)
export function cartCount() {
  const cart = getCart();
  let total = 0;
  for (let i = 0; i < cart.length; i++) {
    total += cart[i].qty;
  }
  return total;
}

// Đổi giỏ hàng thành các dòng đầy đủ: có tên món, giá...
export function cartLines() {
  const cart = getCart();
  const lines = [];
  for (let i = 0; i < cart.length; i++) {
    const item = cart[i];
    // tìm món và size tương ứng
    for (let j = 0; j < db.products.length; j++) {
      const p = db.products[j];
      if (p.id !== item.productId) continue;
      for (let k = 0; k < p.sizes.length; k++) {
        if (p.sizes[k].size === item.size) {
          lines.push({ index: i, productId: p.id, stock: Number(p.stock) || 0, name: p.name, size: item.size, price: p.sizes[k].price, qty: item.qty });
        }
      }
    }
  }
  return lines;
}

// Tổng tiền hàng
export function subtotalOf(lines) {
  let sum = 0;
  for (let i = 0; i < lines.length; i++) {
    sum += lines[i].price * lines[i].qty;
  }
  return sum;
}

// Phí giao hàng: miễn phí nếu đủ tiền, ngược lại tính phí cố định
export function shipFee(subtotal) {
  if (subtotal === 0 || subtotal >= db.shop.freeShipFrom) return 0;
  return db.shop.shipFee;
}
