/* =====================================================================
   FILE: events.js - BẮT SỰ KIỆN
   Thay vì gắn sự kiện cho từng nút, ta chỉ "lắng nghe" cả trang 5 loại sự kiện:
     1. click   : nút có data-act="ten"   ->  chạy actions.ten(nút đó)
     2. submit  : form có id="tenForm"    ->  chạy forms.tenForm(form đó)
     3. input   : gõ chữ vào ô có id="x"  ->  chạy inputs.x(ô đó)
     4. change  : đổi ô chọn data-chg="y" ->  chạy changes.y(ô đó)
     5. keydown : bấm phím Esc            ->  đóng hộp thoại

   4 "hộp" actions / forms / inputs / changes được export ra.
   Các file khác import về rồi bỏ hàm xử lý vào, ví dụ:
       import { actions } from "./events.js";
       actions.menuCat = function (el) { ... };
   ===================================================================== */

import { closeModal } from "./helpers.js";

export const actions = {};  // actions.ten = function (el) {...}   -> bấm nút có data-act="ten"
export const forms = {};    // forms.idForm = function (f) {...}   -> gửi form có id="idForm"
export const changes = {};  // changes.ten = function (el) {...}   -> đổi ô chọn có data-chg="ten"
export const inputs = {};   // inputs.idO = function (el) {...}    -> gõ vào ô có id="idO"

actions.closeModal = function () {
  closeModal();
};

// 1. Bấm chuột
document.addEventListener("click", function (e) {
  // Bấm ra ngoài hộp thoại (nền đen) thì đóng
  if (e.target.id === "modal") {
    closeModal();
    return;
  }

  // closest tìm phần tử gần nhất (kể cả chính nó) có thuộc tính data-act
  const el = e.target.closest("[data-act]");
  if (!el) return;

  const name = el.dataset.act; // lấy giá trị của data-act
  if (actions[name]) {
    actions[name](el);
  }
});

// 2. Gửi form
document.addEventListener("submit", function (e) {
  e.preventDefault(); // chặn trình duyệt tải lại trang
  // Dùng getAttribute("id") vì form có ô tên "id" (input ẩn) sẽ làm e.target.id trả về ô input chứ không phải chữ
  const handler = forms[e.target.getAttribute("id")];
  if (handler) {
    handler(e.target);
  }
});

// 3. Gõ chữ vào ô (ô tìm kiếm...)
document.addEventListener("input", function (e) {
  if (inputs[e.target.id]) {
    inputs[e.target.id](e.target);
  }
});

// 4. Đổi ô chọn (select, chọn file...)
document.addEventListener("change", function (e) {
  const kind = e.target.dataset.chg;
  if (kind && changes[kind]) {
    changes[kind](e.target);
  }
});

// 5. Bấm phím Esc thì đóng hộp thoại
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape") closeModal();
});
