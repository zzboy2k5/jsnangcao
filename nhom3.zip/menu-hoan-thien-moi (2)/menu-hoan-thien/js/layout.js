/* =====================================================================
   FILE: layout.js - KHUNG TRANG (HEADER + FOOTER)
   Hai phần này xuất hiện ở mọi trang của khách.
   HTML nằm ở:  html/layout/header.html, footer.html, nav-guest.html, nav-user.html, nav-admin.html
   ===================================================================== */

import { $, loadHTML, fill, safe } from "./helpers.js";
import { db, me, isAdmin } from "./data.js";
import { cartCount } from "./cart-data.js";
import { actions } from "./events.js";

// Vẽ thanh menu trên cùng. current = tên trang đang mở (để tô đậm mục đó)
export async function renderHeader(current) {
  // Các mục bên phải thay đổi tùy người đang đăng nhập
  let userLinks = "";
  if (me === null) {
    userLinks = await loadHTML("html/layout/nav-guest.html");
  } else if (isAdmin()) {
    userLinks = await loadHTML("html/layout/nav-admin.html");
  } else {
    userLinks = fill(await loadHTML("html/layout/nav-user.html"), {
      name: safe(me.name),
      cartCount: cartCount()
    });
  }

  const header = await loadHTML("html/layout/header.html");
  $("header").innerHTML = fill(header, { shopName: safe(db.shop.name), userLinks: userLinks });

  // Tô đậm mục menu của trang đang mở
  const link = document.querySelector('#nav a[href="#/' + current + '"]');
  if (link) link.classList.add("active");
}

// Vẽ chân trang (thông tin cửa hàng)
export async function renderFooter() {
  const s = db.shop;
  const footer = await loadHTML("html/layout/footer.html");
  $("footer").innerHTML = fill(footer, {
    shopName: safe(s.name),
    address: safe(s.address),
    hotline: safe(s.hotline),
    email: safe(s.email)
  });
}

// Khi bấm nút ☰ (màn hình nhỏ) thì mở / đóng menu
actions.burger = function () {
  $("nav").classList.toggle("open");
};
